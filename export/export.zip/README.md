Hi im bad at writing readmes
This is a port of the first part of Emerald Coast from Sonic Adventure 1

You can give me feedback on the WEBFISHING Modding Community discord!

	3.1.0 This was going to be part of 4.0.0, but it might take a while more, so heres the new stuff:
		- Checkpoints now work
		- Dash Pannels now work, might need some tweaking
		- Rings will give you 5 bucks and take longer to respawn!
		- Slightly better collisions
		- Secret from main game now works in this map too
		- Better map boundaries
		- Changed some SFX, still working on them tho
		- BlueberryWolfi's APIs is now a dependency, please make sure to have it!

	3.0.1 I fucked up the spawn ponit sorgy, its fixed

	3.0.0 Well, i am a bit fixated on this map so, i added rings and the bridge is interactive now!

	2.0.4 - I.. i fucked up a chalkzone, fixed

	2.0.3 - Fixed some collisions and fixed easter egg AGAIN, Removed Herobrine

	2.0.2 - I MAY or may not have uploaded the wrong file

	2.0.1 - Fixed easter egg and domain expansions showing on the horizon

	2.0.0 - Worked on getting collisions to be smoother, no getting stuck on metal leaves anymore